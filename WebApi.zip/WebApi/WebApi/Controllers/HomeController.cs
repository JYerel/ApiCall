﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using ApiLibrary;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using WebApi.Models;

namespace WebApi.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            AlbumModel album = new AlbumModel();
            return View();
        }

        //[HttpGet]
        public IActionResult GetAlbum()
        {
            return View();
        }

        [HttpGet]
        public async Task<ActionResult> GetAlbum(AlbumModel album)
        {
            AlbumProcess startAlbumProcess = new AlbumProcess();
            startAlbumProcess.StartConnection();

            //if (ModelState.IsValid)
            if (album.UserId > 0)
            {
                await LoadItem(album.UserId);

                if (AlbumProcess.albumList.Count > 0)
                {
                    return Json(AlbumProcess.albumList);
                }
                return View();
            }
            else
            {
                return RedirectToAction("Index"); 
            }
        }

        private async Task LoadItem(int userID = 0)
        {
            var albums = await AlbumProcess.LoadAlbumTask(userID);
            // Display Image, e.g. https://via.placeholder.com/150/771796
            // ** Remind me ** --<<
            //var webSource = new Uri(albums.Id.ToString(), UriKind.Absolute);

        }

    }
}
