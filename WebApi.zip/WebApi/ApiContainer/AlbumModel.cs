﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace ApiLibrary
{
    public class AlbumModel
    {
        // add more client side validation ** remenber me **
        [Range(1, 10, ErrorMessage = "User ID does not exist in the album")]
        public int UserId { get; set; }

        [Range(1, 100, ErrorMessage = "Album ID does not exist in the album")]
        public int Id { get; set; }

        public string Title { get; set; }

        public AlbumModel()
        {
            //ApiContainer apiContainer = new ApiContainer();
            //apiContainer.InitialiseClient();
        }
    }
}
