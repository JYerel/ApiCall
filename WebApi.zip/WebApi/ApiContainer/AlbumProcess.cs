﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Resources;
using System.Text;
using System.Threading.Tasks;


namespace ApiLibrary
{
    public class AlbumProcess
    {
        public static List<AlbumModel> albumList = new List<AlbumModel>();

        // Add return vals
        public static async Task<List<AlbumModel>> LoadAlbumTask(int albumNumer = 0)
        {
            string url = SetApiUrl(albumNumer);
            
            using (HttpResponseMessage response = await ApiContainer.WebClient.GetAsync(url))
            {
                if (response.IsSuccessStatusCode)
                {
                    List<AlbumModel> albumList = await response.Content.ReadAsAsync<List<AlbumModel>>();
                    AlbumProcess.albumList = albumList;
                    //var jsonString = await ApiContainer.WebClient.GetStringAsync(url);
                    //List<AlbumModel> albumList = JsonConvert.DeserializeObject<List<AlbumModel>>(jsonString);

                    return albumList;
                }
                else
                {
                    throw new Exception(response.ReasonPhrase);
                }

            }
        }

        public static string SetApiUrl(int userId)
        {
            if (userId > 0)
            {
                return $"http://jsonplaceholder.typicode.com/albums?userId={userId}";
            }
            else
            {
                return $"http://jsonplaceholder.typicode.com/albums";
            }
        }

        public void StartConnection()
        {
            ApiContainer apiContainer = new ApiContainer();
            apiContainer.InitialiseClient();
        }

    }
}
