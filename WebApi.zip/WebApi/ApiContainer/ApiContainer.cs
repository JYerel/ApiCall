﻿using System;
using System.Dynamic;
using System.Net.Http;
using System.Net.Http.Headers;

namespace ApiLibrary
{
    public class ApiContainer
    {
        public static HttpClient WebClient { get; set; }

        public void InitialiseClient()
        {
            WebClient = new HttpClient();
            WebClient.BaseAddress = new Uri("http://jsonplaceholder.typicode.com/");
            WebClient.DefaultRequestHeaders.Accept.Clear();
            WebClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }
    }
}
